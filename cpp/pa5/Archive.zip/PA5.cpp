#include <iostream>

#include "Game.h"
using namespace std;


int main() {
	Game game("game.txt"); // 0 2 3 0 5 1 4 5 1 2
	game.start();

	return 0;
}
