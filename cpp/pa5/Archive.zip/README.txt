/**********************************************************************
 *  readme.txt
 **********************************************************************/

Name: Tushar JAIN
Nickname or English name: Tushar
Major: BSc. Economics and Finance
Course: COMP 2012H
Email address: tjain@connect.ust.hk
Programming assignment #: 5
OS: OSX El Capitan 10.11
Compiler: g++ 4.2.1
Hours spent: 10

/**********************************************************************
 *  List whatever help (if any) that you received.
 **********************************************************************/
I have sought help from the following people: N/A
I have read the following books: N/A
I have consulted the following websites: N/A

The work included in this program is all my own work (Y/N): Y

/**********************************************************************
 *  Explain your overall approach and the unique features of your program
 **********************************************************************/

The program can be compiled using the Makefile. The output file is “game”, which can be executed using “./game”.

/**********************************************************************
 *  Describe any serious problems your program has, or anything which
 *  you have not implemented successfully
 **********************************************************************/
N/A

/**********************************************************************
 *  State the input files you used to test your program
 **********************************************************************/
N/A

/**********************************************************************
 *  Known bugs / limitations of the program
 **********************************************************************/
N/A

/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback
 *  on how much you learned from doing the assignment, whether
 *  you like the assignment or not, and how the assignment may be
 *  improved
 **********************************************************************/
